import { users, contactMessages, projects, type User, type InsertUser, type ContactMessage, type InsertContactMessage, type Project, type InsertProject } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  
  getProjects(): Promise<Project[]>;
  getFeaturedProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contactMessages: Map<number, ContactMessage>;
  private projects: Map<number, Project>;
  private currentUserId: number;
  private currentContactMessageId: number;
  private currentProjectId: number;

  constructor() {
    this.users = new Map();
    this.contactMessages = new Map();
    this.projects = new Map();
    this.currentUserId = 1;
    this.currentContactMessageId = 1;
    this.currentProjectId = 1;
    
    // Initialize with some sample projects
    this.initializeProjects();
  }

  private initializeProjects() {
    const sampleProjects: InsertProject[] = [
      {
        title: "Biometric Door Lock System",
        description: "Smart security solution using fingerprint authentication for keyless entry. Features IoT connectivity, real-time monitoring, and enhanced security management to eliminate key loss and PIN vulnerabilities.",
        image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        technologies: ["IoT", "Biometric Sensors", "Embedded Systems", "Security"],
        liveUrl: null,
        githubUrl: null,
        featured: true
      },

      {
        title: "E-commerce Website",
        description: "Full-featured shopping website with product listings, shopping cart functionality, and user management. Developed with Java-based backend architecture for robust performance.",
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        technologies: ["Java", "Web Development", "E-commerce", "Backend"],
        liveUrl: null,
        githubUrl: null,
        featured: true
      },

      {
        title: "To-Do List Application",
        description: "Task management application with CLI and GUI interfaces for adding, removing, and managing daily tasks. Developed using Python with focus on user experience and functionality.",
        image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        technologies: ["Python", "Tkinter", "GUI", "Task Management"],
        liveUrl: null,
        githubUrl: null,
        featured: true
      },
      {
        title: "Calculator Application",
        description: "Arithmetic calculator with graphical user interface built using Python Tkinter. Features basic mathematical operations with intuitive design and error handling.",
        image: "https://images.unsplash.com/photo-1587145820266-a5951ee6f620?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        technologies: ["Python", "Tkinter", "GUI", "Mathematics"],
        liveUrl: null,
        githubUrl: null,
        featured: true
      },
      {
        title: "Blogging Platform",
        description: "Content management platform where users can create, publish, and manage blog posts. Java backend handles database operations, user authentication, and content management features.",
        image: "https://images.unsplash.com/photo-1486312338219-ce68e2c6c3eb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        technologies: ["Java", "Web Development", "CMS", "Database"],
        liveUrl: null,
        githubUrl: null,
        featured: false
      }
    ];

    sampleProjects.forEach(project => {
      this.createProject(project);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentContactMessageId++;
    const message: ContactMessage = { 
      ...insertMessage, 
      id, 
      createdAt: new Date() 
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getFeaturedProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.featured);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { ...insertProject, id };
    this.projects.set(id, project);
    return project;
  }
}

export const storage = new MemStorage();
