# Likitha Yechina - Portfolio Website

A modern, responsive portfolio website showcasing my academic background in Electronics & Computer Science, internship experiences, and technical projects.

## 🚀 Features

- **Modern Design**: Clean, professional layout with responsive design
- **Interactive Sections**: Hero, About, Projects, Certifications, and Contact
- **Real Projects**: Featuring actual internship work and academic projects
- **Contact Form**: Working contact form for opportunities and collaborations
- **Mobile Responsive**: Optimized for all device sizes

## 🛠️ Tech Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Build Tool**: Vite
- **State Management**: TanStack Query

## 📋 Projects Featured

- **Biometric Door Lock System**: Arduino-based security system with fingerprint authentication
- **E-commerce Website**: Full-featured shopping platform with Java backend
- **To-Do List Application**: Task management app with CLI and GUI interfaces
- **Calculator Application**: Feature-rich calculator with scientific functions
- **Blogging Platform**: Content management system with user authentication

## 🎓 Education & Certifications

- **B.Tech in Electronics & Computer Science Engineering** - KKR & KSR Institute of Technology & Sciences
- **Cisco Certified Network Associate (CCNA)** - Networking fundamentals and protocols
- **Swayam Plus Certificate** - Advanced programming and development

## 💼 Internship Experience

- **EdyGrad** - Web Development Intern (Java, Backend Development)
- **TechnoHacksEdutech** - Python Development Intern (GUI Applications, APIs)

## 🚀 Getting Started

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/likitha-portfolio.git
cd likitha-portfolio
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm run dev
```

4. Open your browser and visit `http://localhost:5000`

## 📦 Build for Production

```bash
npm run build
```

## 📝 Environment Variables

Create a `.env` file in the root directory:
```
DATABASE_URL=your_postgresql_connection_string
NODE_ENV=development
```

## 📱 Contact

- **Email**: likithayechina@gmail.com
- **Location**: Hyderabad, India
- **LinkedIn**: [Your LinkedIn Profile]
- **GitHub**: [Your GitHub Profile]

## 🎯 Career Interests

- Software Development
- Web Development
- IoT and Electronics
- Data Science and Analytics
- Internship Opportunities

---

*This portfolio is continuously updated with new projects and experiences. Feel free to reach out for collaborations or opportunities!*