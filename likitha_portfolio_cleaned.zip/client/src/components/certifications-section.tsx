import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Trophy, Users, Code } from "lucide-react";

export default function CertificationsSection() {
  const certifications = [
    {
      title: "Cisco CCNA - Introduction to Cyber Security",
      issuer: "Cisco",
      icon: "🔒",
      category: "Security"
    },
    {
      title: "Python Essentials - I",
      issuer: "Cisco CCNA",
      icon: "🐍",
      category: "Programming"
    },
    {
      title: "Python Essentials - II",
      issuer: "Cisco CCNA",
      icon: "🐍",
      category: "Programming"
    },
    {
      title: "Semiconductors - VLSI Embedded System",
      issuer: "Swayam Plus",
      icon: "⚡",
      category: "Electronics"
    }
  ];

  const achievements = [
    {
      title: "Academic Excellence",
      description: "Pursuing ECE Degree with CGPA of 8.62",
      icon: <Award className="w-6 h-6 text-yellow-500" />,
      color: "bg-yellow-500/10 text-yellow-600"
    },
    {
      title: "Smart India Hackathon",
      description: "Participated in National Level Competition",
      icon: <Code className="w-6 h-6 text-blue-500" />,
      color: "bg-blue-500/10 text-blue-600"
    },
    {
      title: "Community Service",
      description: "Organized events for local NGOs and awareness campaigns",
      icon: <Users className="w-6 h-6 text-green-500" />,
      color: "bg-green-500/10 text-green-600"
    },
    {
      title: "National Youth Festival",
      description: "Active participation in cultural and technical events",
      icon: <Trophy className="w-6 h-6 text-purple-500" />,
      color: "bg-purple-500/10 text-purple-600"
    }
  ];

  const workshops = [
    "Data Structures Workshop",
    "VLSI Technology Workshop",
    "Web Development Bootcamp",
    "Embedded Systems Training"
  ];

  return (
    <section id="certifications" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Certifications & Achievements</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Professional certifications, academic achievements, and recognition that demonstrate my commitment to continuous learning.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Certifications */}
          <div>
            <h3 className="text-2xl font-semibold text-slate-800 mb-8">Professional Certifications</h3>
            <div className="space-y-6">
              {certifications.map((cert, index) => (
                <Card key={index} className="shadow-lg card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="text-3xl mr-4">{cert.icon}</div>
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-slate-800 mb-2">{cert.title}</h4>
                        <p className="text-slate-600 mb-2">{cert.issuer}</p>
                        <Badge variant="secondary" className="bg-blue-600/10 text-blue-600">
                          {cert.category}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Academic Highlights */}
          <div>
            <h3 className="text-2xl font-semibold text-slate-800 mb-8">Academic Highlights</h3>
            <div className="space-y-6">
              {achievements.map((achievement, index) => (
                <Card key={index} className="shadow-lg card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-start">
                      <div className="mr-4">{achievement.icon}</div>
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-slate-800 mb-2">{achievement.title}</h4>
                        <p className="text-slate-600">{achievement.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Workshops */}
            <div className="mt-8">
              <h4 className="text-lg font-medium text-slate-800 mb-4">Workshops & Training</h4>
              <div className="flex flex-wrap gap-2">
                {workshops.map((workshop, index) => (
                  <Badge key={index} variant="outline" className="text-sm">
                    {workshop}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}