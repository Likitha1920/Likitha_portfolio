import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function AboutSection() {
  const educationItems = [
    {
      period: "2022 - 2026",
      title: "Bachelor of Technology - Electronics and Computer Science",
      institution: "Vignan's Institute of Information Technology",
      description: "CGPA: 8.62 | Relevant Coursework: Electronics, Computer Science, VLSI Technology, Embedded Systems",
      color: "bg-blue-600/10 text-blue-600"
    },
    {
      period: "May 2024 - Jun 2024",
      title: "Python Developer Intern",
      institution: "TechnoHacksEdutech",
      description: "Developed To-Do List App, Calculator with Tkinter, and Weather App using APIs. Gained experience in Python GUI development.",
      color: "bg-yellow-500/10 text-yellow-600"
    },
    {
      period: "Apr 2024 - May 2024",
      title: "Web Development Intern",
      institution: "EdyGrad",
      description: "Built Online Quiz System, E-commerce Website, and Blogging Platform using Java backend and web technologies.",
      color: "bg-green-500/10 text-green-600"
    },
    {
      period: "2020 - 2022",
      title: "Intermediate (MPC)",
      institution: "Sri Chaitanya Junior College",
      description: "Examination Score: 93% | Mathematics, Physics, Chemistry focus",
      color: "bg-purple-500/10 text-purple-600"
    }
  ];

  const skills = [
    { name: "Python", level: 90 },
    { name: "C Language", level: 85 },
    { name: "Web Development", level: 80 },
    { name: "HTML/CSS", level: 85 }
  ];

  const tools = [
    { name: "MS Office", icon: "📊" },
    { name: "MATLAB", icon: "📈" },
    { name: "Git", icon: "🔧" },
    { name: "VLSI Design", icon: "⚡" }
  ];

  return (
    <section id="about" className="py-20 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">About Me</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            I'm a dedicated Electronics & Computer Science student with a passion for technology, web development, and innovative solutions. 
            Here's my educational journey and professional experience.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h3 className="text-2xl font-semibold text-slate-800 mb-8">Education & Experience</h3>
            <div className="relative border-l-2 border-blue-600/20 pl-8 space-y-8">
              {educationItems.map((item, index) => (
                <div key={index} className="timeline-item relative">
                  <Card className="shadow-lg card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-2">
                        <span className={`${item.color} px-3 py-1 rounded-full text-sm font-medium`}>
                          {item.period}
                        </span>
                      </div>
                      <h4 className="text-lg font-semibold text-slate-800 mb-2">{item.title}</h4>
                      <p className="text-slate-600 mb-2">{item.institution}</p>
                      <p className="text-sm text-slate-500">{item.description}</p>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-semibold text-slate-800 mb-8">Skills & Technologies</h3>
            
            <div className="mb-8">
              <h4 className="text-lg font-medium text-slate-800 mb-4">Programming Languages</h4>
              <div className="space-y-4">
                {skills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-slate-600 font-medium">{skill.name}</span>
                      <span className="text-sm text-slate-500">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-lg font-medium text-slate-800 mb-4">Tools & Technologies</h4>
              <div className="grid grid-cols-2 gap-4">
                {tools.map((tool, index) => (
                  <Card key={index} className="shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl mb-2">{tool.icon}</div>
                      <span className="text-sm font-medium text-slate-600">{tool.name}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
