import { Button } from "@/components/ui/button";
import { Github, Linkedin, Twitter, Mail } from "lucide-react";
import profileImage from "@assets/my pic r_1751288412347.jpg";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section id="home" className="pt-16 min-h-screen flex items-center gradient-bg">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Hi, I'm <span className="text-yellow-400">Likitha Yechina</span>
            </h1>
            <p className="text-xl lg:text-2xl mb-8 text-blue-100">
              Electronics & Computer Science Student
            </p>
            <p className="text-lg mb-8 text-blue-200 leading-relaxed">
              Passionate about electronics, web development, and innovative technology solutions. 
              Currently pursuing my B.Tech degree while building real-world projects and gaining hands-on experience through internships.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                onClick={() => scrollToSection('projects')}
                className="bg-yellow-500 text-white hover:bg-yellow-600 px-8 py-3 text-center font-semibold"
              >
                View My Work
              </Button>
              <Button 
                onClick={() => scrollToSection('contact')}
                variant="outline" 
                className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 text-center font-semibold"
              >
                Get In Touch
              </Button>
            </div>
            
            <div className="flex space-x-6">
              <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                <Github className="w-6 h-6" />
              </a>
              <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                <Linkedin className="w-6 h-6" />
              </a>
              <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                <Twitter className="w-6 h-6" />
              </a>
              <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                <Mail className="w-6 h-6" />
              </a>
            </div>
          </div>
          
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="w-80 h-80 rounded-2xl bg-white/10 backdrop-blur-sm p-8 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <div className="w-full h-full rounded-xl overflow-hidden">
                  <img 
                    src={profileImage} 
                    alt="Likitha Yechina - Professional headshot" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-yellow-400/20 rounded-full animate-pulse"></div>
              <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-white/20 rounded-full animate-bounce" style={{animationDelay: '1s'}}></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
