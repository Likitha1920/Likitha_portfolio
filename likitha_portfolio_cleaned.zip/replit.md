# Likitha Yechina Portfolio Application

## Overview

This is a modern, full-stack student portfolio application built with React, Express, and TypeScript. The application showcases Likitha Yechina's professional portfolio featuring her Electronics & Computer Science background, internship projects, certifications, and contact information. It's designed to present her technical skills and experience in a polished, responsive format.

## System Architecture

The application follows a monorepo structure with clear separation between client-side and server-side code:

- **Frontend**: React SPA with TypeScript, built using Vite
- **Backend**: Express.js REST API with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **Client Directory**: Contains the React application
- **Component Library**: Uses shadcn/ui for consistent, accessible UI components
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Navigation**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **State Management**: TanStack Query for API data fetching and caching

### Backend Architecture
- **Express Server**: RESTful API built with Express.js
- **Database Layer**: Drizzle ORM for type-safe database operations
- **Storage Pattern**: Interface-based storage abstraction with in-memory implementation
- **Error Handling**: Centralized error handling middleware
- **Logging**: Custom request/response logging for API endpoints

### Database Schema
- **Users Table**: Basic user authentication structure
- **Projects Table**: Portfolio projects with metadata, images, and links
- **Contact Messages Table**: Form submissions from the contact page

### UI Components
The application uses a comprehensive set of shadcn/ui components including:
- Navigation components (menus, breadcrumbs)
- Form elements (inputs, textareas, buttons, selects)
- Display components (cards, badges, progress bars)
- Feedback components (toasts, alerts, dialogs)
- Layout components (separators, scroll areas, tabs)

## Data Flow

1. **Client Requests**: React components use TanStack Query to fetch data
2. **API Layer**: Express routes handle HTTP requests and validate input
3. **Business Logic**: Storage interface provides data access abstraction
4. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
5. **Response Flow**: Data flows back through the same layers with proper error handling

## External Dependencies

### Core Framework Dependencies
- **React 18**: Frontend framework with modern hooks and concurrent features
- **Express**: Backend web framework
- **TypeScript**: Type safety across the entire application
- **Vite**: Build tool and development server

### Database & ORM
- **Drizzle ORM**: Type-safe database operations
- **@neondatabase/serverless**: PostgreSQL client for serverless environments
- **connect-pg-simple**: PostgreSQL session store

### UI & Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library
- **class-variance-authority**: Component variant management

### Form & Validation
- **React Hook Form**: Form state management
- **Zod**: Schema validation
- **@hookform/resolvers**: Integration between React Hook Form and Zod

### Development Tools
- **TSX**: TypeScript execution for development
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer

## Deployment Strategy

The application is configured for modern deployment patterns:

- **Development**: Uses Vite dev server with HMR and Express API
- **Production Build**: 
  - Frontend builds to `dist/public` directory
  - Backend bundles with ESBuild to `dist/index.js`
- **Database**: Configured for PostgreSQL with environment-based connection strings
- **Static Assets**: Frontend serves static files in production
- **Environment Variables**: Uses `DATABASE_URL` for database connectivity

The build process creates a single deployable artifact that can run on any Node.js hosting platform.

## Changelog
- June 30, 2025. Initial setup
- June 30, 2025. Customized portfolio for Likitha Yechina based on her resume:
  - Updated personal information (name, contact details, location)
  - Replaced projects with her actual internship work and academic projects
  - Added certifications section showcasing Cisco CCNA and Swayam Plus credentials
  - Updated skills to reflect Electronics & Computer Science background
  - Added achievements including Smart India Hackathon participation

## User Preferences

Preferred communication style: Simple, everyday language.